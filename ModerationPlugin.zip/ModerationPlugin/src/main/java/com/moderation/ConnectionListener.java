package com.moderation;

import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.event.PluginMessageEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;
import java.util.List;
import java.util.Map;
import java.nio.charset.StandardCharsets;

public class ConnectionListener implements Listener {
    private final ModerationPlugin plugin;
    private static final String[] BLOCKED_WORDS = {
        "fuck", "shit", "damn", "hell", "bastard", "bitch", "ass", "pussy", "dick", "cunt", "nigger", "crap", "screw", "motherfucker", "whore", "slut", "dickhead", "asshole", "jerk", "dickwad", "piss", "twat", "prick", "cocksucker", "fag", "queer", "dyke", "retard", "spaz", "dumbass", "idiot", "moron", "dope", "dork", "dickweed", "assclown", "douchebag", "douche", "asshat", "dipshit", "shithead", "shitfaced"
    };
    private final Map<String, String> playerBrands = new java.util.concurrent.ConcurrentHashMap<>();

    public ConnectionListener(ModerationPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPluginMessage(PluginMessageEvent event) {
        if (!(event.getReceiver() instanceof ProxiedPlayer)) return;
        ProxiedPlayer player = (ProxiedPlayer) event.getReceiver();
        String channel = event.getTag();
        if (!channel.equalsIgnoreCase("MC|Brand") && !channel.equalsIgnoreCase("minecraft:brand")) return;
        String brand = new String(event.getData(), StandardCharsets.UTF_8);
        playerBrands.put(player.getName(), brand);
        if (plugin.isBrandStringLoggingEnabled()) {
            plugin.getLogger().info("Brand string for " + player.getName() + ": " + brand);
        }
    }

    @EventHandler
    public void onPostLogin(PostLoginEvent event) {
        ProxiedPlayer player = event.getPlayer();
        String ip = player.getAddress().getAddress().getHostAddress();
        StringBuilder alert = new StringBuilder();
        alert.append("§c[Moderation Alert] Player: §e").append(player.getName()).append("§c | IP: §e").append(ip);
        if (plugin.isNameFilterEnabled()) {
            String lowerName = player.getName().toLowerCase();
            for (String word : BLOCKED_WORDS) {
                if (lowerName.contains(word)) {
                    player.disconnect("§cYour username contains a blocked word and is not allowed on this server.");
                    plugin.getLogger().info("Blocked player '" + player.getName() + "' for inappropriate username.");
                    return;
                }
            }
        }
        if (plugin.isGeoipDetectionEnabled()) {
            String country = plugin.getGeoIPUtil().lookupCountry(ip);
            alert.append("§c | Country: §e").append(country);
        }
        boolean isVPN = false;
        if (plugin.isVpnProxyDetectionEnabled()) {
            isVPN = plugin.getVPNUtil().isVPN(ip);
            alert.append("§c | VPN/Proxy: §e").append(isVPN ? "Yes" : "No");
        }
        boolean aiFlagged = false;
        if (plugin.isAiEvaderDetectionEnabled()) {
            String aiResult = plugin.getHuggingFaceUtil().query(player.getName() + " " + ip);
            aiFlagged = aiResult != null && aiResult.toLowerCase().contains("true");
            alert.append("§c | AI Flagged: §e").append(aiFlagged ? "Yes" : "No");
        }
        if (plugin.isClientVersionDetectionEnabled()) {
            String version = "Unknown";
            String clientBrand = "Unknown";
            alert.append("§c | Version: §e").append(version);
            alert.append("§c | Client: §e").append(clientBrand);
        }
        if (plugin.isEaglercraftDetectionEnabled()) {
            String brand = playerBrands.getOrDefault(player.getName(), "Unknown");
            String detectedClient = "Not Eaglercraft";
            String detectedVersion = "Not Eaglercraft";
            Map<String, List<String>> packetSignatures = plugin.getPacketSignatures();
            if (packetSignatures != null) {
                for (Map.Entry<String, List<String>> entry : packetSignatures.entrySet()) {
                    for (String sig : entry.getValue()) {
                        if (brand.toLowerCase().contains(sig.toLowerCase())) {
                            detectedClient = capitalize(entry.getKey());
                            detectedVersion = brand;
                        }
                    }
                }
            }
            alert.append("§c | Eaglercraft Version: §e").append(detectedVersion);
            alert.append("§c | Eaglercraft Client: §e").append(detectedClient);
        }
        for (ProxiedPlayer p : ProxyServer.getInstance().getPlayers()) {
            if (p.hasPermission("moderationplugin.admin.alert")) {
                p.sendMessage(alert.toString());
            }
        }
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
    }
}
