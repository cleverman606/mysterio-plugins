package com.moderation;

import com.maxmind.geoip2.WebServiceClient;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;
import java.io.IOException;

public class GeoIPUtil {
    private final WebServiceClient client;

    public GeoIPUtil(String licenseKey) {
        this.client = new WebServiceClient.Builder(0, licenseKey).build();
    }

    public String lookupCountry(String ip) {
        try {
            CityResponse response = client.city(ip);
            return response.getCountry().getName();
        } catch (IOException | GeoIp2Exception e) {
            return "Unknown";
        }
    }
}
