package com.moderation;

import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.api.plugin.Listener;
import com.moderation.ConnectionListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import org.yaml.snakeyaml.Yaml;
import java.util.Properties;
import java.util.Map;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.plugin.Command;
import net.md_5.bungee.api.event.PluginMessageEvent;
import java.util.List;
import net.md_5.bungee.api.connection.ProxiedPlayer;

public class ModerationPlugin extends Plugin {
    private String maxmindLicenseKey;
    private GeoIPUtil geoIPUtil;
    private VPNUtil vpnUtil;
    private HuggingFaceUtil huggingFaceUtil;
    private Map<String, List<String>> packetSignatures;

    private boolean geoipDetection = true;
    private boolean vpnProxyDetection = true;
    private boolean aiEvaderDetection = true;
    private boolean networkAlerts = true;
    private boolean clientVersionDetection = true;
    private boolean eaglercraftDetection = true;
    private boolean nameFilter = true;
    private boolean brandStringLogging = true;

    @Override
    public void onEnable() {
        Properties config = new Properties();
        try (InputStream in = getResourceAsStream("config.properties")) {
            if (in != null) {
                config.load(in);
                maxmindLicenseKey = config.getProperty("maxmind.license_key");
            }
        } catch (IOException e) {
            getLogger().warning("Could not load config.properties: " + e.getMessage());
        }


        try {
            File pluginDir = new File(getDataFolder(), "..");
            File configFile = new File(pluginDir, "ModerationPlugin/plugin.yml");
            if (configFile.exists()) {
                Yaml yaml = new Yaml();
                try (FileInputStream fis = new FileInputStream(configFile)) {
                    Map<String, Object> yamlData = yaml.load(fis);
                    if (yamlData != null && yamlData.containsKey("settings")) {
                        Map<String, Object> settings = (Map<String, Object>) yamlData.get("settings");
                        geoipDetection = Boolean.TRUE.equals(settings.getOrDefault("geoip_detection", true));
                        vpnProxyDetection = Boolean.TRUE.equals(settings.getOrDefault("vpn_proxy_detection", true));
                        aiEvaderDetection = Boolean.TRUE.equals(settings.getOrDefault("ai_evader_detection", true));
                        networkAlerts = Boolean.TRUE.equals(settings.getOrDefault("network_alerts", true));
                        clientVersionDetection = Boolean.TRUE.equals(settings.getOrDefault("client_version_detection", true));
                        eaglercraftDetection = Boolean.TRUE.equals(settings.getOrDefault("eaglercraft_detection", true));
                        nameFilter = Boolean.TRUE.equals(settings.getOrDefault("name_filter", true));
                        if (settings.containsKey("packet_signatures")) {
                            packetSignatures = (Map<String, List<String>>) settings.get("packet_signatures");
                        }
                        brandStringLogging = Boolean.TRUE.equals(settings.getOrDefault("brand_string_logging", true));
                    }
                }
            }
        } catch (Exception e) {
            getLogger().warning("Could not load interactive plugin.yml: " + e.getMessage());
        }

        geoIPUtil = new GeoIPUtil(maxmindLicenseKey);
        String iphubKey = config.getProperty("iphub.api_key");
        vpnUtil = new VPNUtil(iphubKey);
        String hfKey = config.getProperty("huggingface.api_key");
        huggingFaceUtil = new HuggingFaceUtil(hfKey, "facebook/roberta-base-openai-detector");
        getLogger().info("ModerationPlugin enabled.");
        getProxy().getPluginManager().registerListener(this, new ConnectionListener(this));
        getProxy().getPluginManager().registerCommand(this, new ModerationPluginCommand(this));
        getProxy().getPluginManager().registerCommand(this, new ReportCommand(this));
    }

    @Override
    public void onDisable() {
        getLogger().info("ModerationPlugin disabled.");
    }

    public String getMaxmindLicenseKey() {
        return maxmindLicenseKey;
    }

    public GeoIPUtil getGeoIPUtil() {
        return geoIPUtil;
    }

    public VPNUtil getVPNUtil() {
        return vpnUtil;
    }

    public HuggingFaceUtil getHuggingFaceUtil() {
        return huggingFaceUtil;
    }

    public Map<String, List<String>> getPacketSignatures() {
        return packetSignatures;
    }

    public boolean isGeoipDetectionEnabled() { return geoipDetection; }
    public boolean isVpnProxyDetectionEnabled() { return vpnProxyDetection; }
    public boolean isAiEvaderDetectionEnabled() { return aiEvaderDetection; }
    public boolean isNetworkAlertsEnabled() { return networkAlerts; }
    public boolean isClientVersionDetectionEnabled() { return clientVersionDetection; }
    public boolean isEaglercraftDetectionEnabled() { return eaglercraftDetection; }
    public boolean isNameFilterEnabled() { return nameFilter; }
    public boolean isBrandStringLoggingEnabled() { return brandStringLogging; }

    public void reloadPluginConfig() {
        try {
            File pluginDir = new File(getDataFolder(), "..");
            File configFile = new File(pluginDir, "ModerationPlugin/plugin.yml");
            if (configFile.exists()) {
                Yaml yaml = new Yaml();
                try (FileInputStream fis = new FileInputStream(configFile)) {
                    Map<String, Object> yamlData = yaml.load(fis);
                    if (yamlData != null && yamlData.containsKey("settings")) {
                        Map<String, Object> settings = (Map<String, Object>) yamlData.get("settings");
                        geoipDetection = Boolean.TRUE.equals(settings.getOrDefault("geoip_detection", true));
                        vpnProxyDetection = Boolean.TRUE.equals(settings.getOrDefault("vpn_proxy_detection", true));
                        aiEvaderDetection = Boolean.TRUE.equals(settings.getOrDefault("ai_evader_detection", true));
                        networkAlerts = Boolean.TRUE.equals(settings.getOrDefault("network_alerts", true));
                        clientVersionDetection = Boolean.TRUE.equals(settings.getOrDefault("client_version_detection", true));
                        eaglercraftDetection = Boolean.TRUE.equals(settings.getOrDefault("eaglercraft_detection", true));
                        nameFilter = Boolean.TRUE.equals(settings.getOrDefault("name_filter", true));
                        if (settings.containsKey("packet_signatures")) {
                            packetSignatures = (Map<String, List<String>>) settings.get("packet_signatures");
                        }
                        brandStringLogging = Boolean.TRUE.equals(settings.getOrDefault("brand_string_logging", true));
                    }
                }
            }
            getLogger().info("ModerationPlugin configuration reloaded!");
        } catch (Exception e) {
            getLogger().warning("Could not reload interactive plugin.yml: " + e.getMessage());
        }
    }
}

class ModerationPluginCommand extends Command {
    private final ModerationPlugin plugin;
    public ModerationPluginCommand(ModerationPlugin plugin) {
        super("moderationplugin", null);
        this.plugin = plugin;
    }
    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("moderationplugin.reload")) {
                sender.sendMessage("§cYou do not have permission to reload the plugin.");
                return;
            }
            plugin.reloadPluginConfig();
            sender.sendMessage("§aModerationPlugin configuration reloaded!");
            return;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("test")) {
            if (!sender.hasPermission("moderationplugin.admin.test")) {
                sender.sendMessage("§cYou do not have permission to use this command.");
                return;
            }
            sender.sendMessage("§aModerationPlugin is running!");
            sender.sendMessage("§eSettings:");
            sender.sendMessage("§7GeoIP Detection: §f" + plugin.isGeoipDetectionEnabled());
            sender.sendMessage("§7VPN/Proxy Detection: §f" + plugin.isVpnProxyDetectionEnabled());
            sender.sendMessage("§7AI Evader Detection: §f" + plugin.isAiEvaderDetectionEnabled());
            sender.sendMessage("§7Network Alerts: §f" + plugin.isNetworkAlertsEnabled());
            sender.sendMessage("§7Client/Version Detection: §f" + plugin.isClientVersionDetectionEnabled());
            sender.sendMessage("§7Eaglercraft Detection: §f" + plugin.isEaglercraftDetectionEnabled());
            sender.sendMessage("§7Name Filter: §f" + plugin.isNameFilterEnabled());
            sender.sendMessage("§7Brand String Logging: §f" + plugin.isBrandStringLoggingEnabled());
            return;
        }
        sender.sendMessage("§cUsage: /moderationplugin <reload|test>");
    }
}

class ReportCommand extends Command {
    private final ModerationPlugin plugin;
    public ReportCommand(ModerationPlugin plugin) {
        super("report", "moderationplugin.report");
        this.plugin = plugin;
    }
    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!sender.hasPermission("moderationplugin.report")) {
            sender.sendMessage("§cYou do not have permission to use this command.");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("§cUsage: /report <player> <reason>");
            return;
        }
        String reported = args[0];
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        String reporter = (sender instanceof ProxiedPlayer) ? sender.getName() : "Console";
        String reportMsg = "§6[Report] §e" + reporter + "§7 reported §c" + reported + "§7: §f" + reason;
        for (ProxiedPlayer p : plugin.getProxy().getPlayers()) {
            if (p.hasPermission("moderationplugin.alert")) {
                p.sendMessage(reportMsg);
            }
        }
        sender.sendMessage("§aYour report has been submitted to the staff.");
    }
}
