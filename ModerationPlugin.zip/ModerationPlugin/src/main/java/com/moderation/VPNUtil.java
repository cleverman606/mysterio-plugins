package com.moderation;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class VPNUtil {
    private final String apiKey;

    public VPNUtil(String apiKey) {
        this.apiKey = apiKey;
    }

    public boolean isVPN(String ip) {
        try {
            URL url = new URL("https://v2.api.iphub.info/ip/" + ip);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("X-Key", apiKey);
            int responseCode = con.getResponseCode();
            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                return response.toString().contains("\"block\":1") || response.toString().contains("\"block\":2");
            }
        } catch (Exception e) {
        }
        return false;
    }
}
